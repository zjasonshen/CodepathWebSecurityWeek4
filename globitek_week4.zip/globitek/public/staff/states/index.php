<?php
require_once('../../../private/initialize.php');
?>
<?php redirect_to('../index.php'); ?>
